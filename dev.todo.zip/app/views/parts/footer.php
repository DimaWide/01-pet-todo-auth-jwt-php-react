<!-- footer.php -->
<footer class="bg-blue-900 text-white text-center p-4 mt-10">
    <p class="font-medium">&copy; 2024 ToDo App. All rights reserved.</p>
</footer>

</div>

<script>const baseUrl = '<?php echo BASE_URL; ?>';</script>
<script src="<?php echo BASE_URL . 'js/auth.js'; ?>"></script>
<script src="<?php echo BASE_URL . 'js/tasks.js'; ?>"></script>
</body>

</html>