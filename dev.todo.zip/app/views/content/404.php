<div class="flex flex-col items-center justify-center  bg-gray-100">
    <h2 class="text-6xl font-bold text-red-600">404</h2>
    <p class="mt-4 text-lg font-bold text-gray-700">Page not found</p>
    <a href="/" class="mt-6 px-4 py-2 text-white bg-blue-500 font-bold hover:bg-blue-600 rounded-lg transition duration-300">Home</a>
</div>
