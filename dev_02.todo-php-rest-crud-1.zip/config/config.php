<?php


use Dotenv\Dotenv;

require_once __DIR__ . '/../vendor/autoload.php';


try {
    $dotenv = Dotenv::createImmutable(__DIR__ );
    $dotenv->load();
} catch (Exception $e) {
    echo "Ошибка при загрузке .env: " . $e->getMessage();
}


// Настройки ошибок: сначала устанавливаем их
ini_set('display_errors', $_ENV['DISPLAY_ERRORS'] === 'On' ? 1 : 0);
ini_set('display_startup_errors', $_ENV['DISPLAY_ERRORS'] === 'On' ? 1 : 0);
error_reporting($_ENV['DISPLAY_ERRORS'] === 'On' ? E_ALL : 0); // Отображать все ошибки только если включено

ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// error_log("Authorization header: " . print_r('test', true)); 

// return [
//     'DB_HOST' => $_ENV['DB_HOST'],
//     'DB_NAME' => $_ENV['DB_NAME'],
//     'DB_USER' => $_ENV['DB_USER'],
//     'DB_PASSWORD' => $_ENV['DB_PASSWORD'],
//     'DB_PORT' => $_ENV['DB_PORT'],
// ];